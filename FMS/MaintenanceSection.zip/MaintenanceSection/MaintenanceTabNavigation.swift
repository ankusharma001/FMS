//
//  MaintenanceTabNavigation.swift
//  FMS
//
//  Created by Vansh Sharma on 20/02/25.
//

//import SwiftUI
//
//struct MaintenanceTabNavigation: View {
//    var body: some View {
//        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
//    }
//}
//
//#Preview {
//    MaintenanceTabNavigation()
//}

import SwiftUI

enum Tab {
    case home
    case inventory
    case profile
}

struct MainNavigationView: View {
    @State private var selectedTab: Tab = .home
    
    var body: some View {
        VStack(spacing: 0) {
            // Content based on selected tab
            switch selectedTab {
            case .home:
                MaintenanceHomeView()
            case .inventory:
                InventoryPlaceholderView()
            case .profile:
                MaintenanceProfileView()
            }
            
            // Custom Tab Bar
            HStack {
                TabBarButton(
                    iconName: "house.fill",
                    title: "Home",
                    isSelected: selectedTab == .home,
                    action: { selectedTab = .home }
                )
                Spacer()
                TabBarButton(
                    iconName: "wrench.fill",
                    title: "Inventory",
                    isSelected: selectedTab == .inventory,
                    action: { selectedTab = .inventory }
                )
                Spacer()
                TabBarButton(
                    iconName: "person.fill",
                    title: "Profile",
                    isSelected: selectedTab == .profile,
                    action: { selectedTab = .profile }
                )
            }
            .padding(.top, 8)
            .padding(.horizontal, 40)
            .padding(.bottom, 20)
            .background(Color.white)
        }
        .edgesIgnoringSafeArea(.bottom)
    }
}

struct TabBarButton: View {
    let iconName: String
    let title: String
    let isSelected: Bool
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            VStack(spacing: 4) {
                Image(systemName: iconName)
                    .font(.system(size: 24))
                    .foregroundColor(isSelected ? .blue : .gray)
                
                Text(title)
                    .font(.caption)
                    .foregroundColor(isSelected ? .blue : .gray)
            }
        }
    }
}

struct InventoryPlaceholderView: View {
    var body: some View {
        VStack {
            Text("Still working on Inventory")
                .font(.title)
                .foregroundColor(.gray)
        }
    }
}

// Preview Provider
struct MainNavigationView_Previews: PreviewProvider {
    static var previews: some View {
        MainNavigationView()
    }
}
