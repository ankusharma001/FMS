//
//  VehicleMaintenanceDetails.swift
//  FMS
//
//  Created by Vansh Sharma on 20/02/25.
//


import SwiftUI

// Additional models needed for maintenance details
struct ServiceRequirement: Identifiable {
    let id = UUID()
    let icon: String
    let title: String
    var status: ServiceStatus
    
    enum ServiceStatus: String {
        case completed = "Completed"
        case inProgress = "In Progress"
        case pending = "Pending"
        
        var color: Color {
            switch self {
            case .completed: return .green
            case .inProgress: return .blue
            case .pending: return .gray
            }
        }
    }
}

struct UsedPart: Identifiable {
    let id = UUID()
    let quantity: Int
    let name: String
    let partNumber: String
    let price: Double
}

struct VehicleMaintenanceDetailView: View {
    let vehicle: Vehicle
    @Environment(\.dismiss) private var dismiss
    @State private var serviceRequirements: [ServiceRequirement] = []
    @State private var usedParts: [UsedPart] = []
    @State private var showStatusUpdateSheet = false
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                // Vehicle Header
                VehicleHeaderView(vehicle: vehicle)
                
                // Status Cards
                StatusCardsView()
                
                // Current Service Details
                VStack(alignment: .leading, spacing: 12) {
                    Text("Current Service Details")
                        .font(.headline)
                    
                    HStack {
                        Image(systemName: "calendar")
                            .foregroundColor(.gray)
                        Text("Service Date")
                            .foregroundColor(.gray)
                        Spacer()
                        Text("Nov 28, 2023")
                    }
                    .padding()
                    .background(Color(.systemGray6))
                    .cornerRadius(10)
                }
                .padding(.horizontal)
                
                // Service Requirements
                VStack(alignment: .leading, spacing: 12) {
                    Text("Service Requirements")
                        .font(.headline)
                        .padding(.horizontal)
                    
                    VStack(spacing: 0) {
                        ForEach(serviceRequirements) { requirement in
                            ServiceRequirementRow(requirement: requirement)
                            if requirement.id != serviceRequirements.last?.id {
                                Divider()
                                    .padding(.leading, 40)
                            }
                        }
                    }
                    .background(Color.white)
                    .cornerRadius(10)
                    .padding(.horizontal)
                }
                
                // Parts & Items Used
                VStack(alignment: .leading, spacing: 12) {
                    Text("Parts & Items Used")
                        .font(.headline)
                        .padding(.horizontal)
                    
                    VStack(spacing: 16) {
                        ForEach(usedParts) { part in
                            UsedPartRow(part: part)
                        }
                    }
                    .padding()
                    .background(Color.white)
                    .cornerRadius(10)
                    .padding(.horizontal)
                }
            }
        }
        .background(Color(.systemGray6))
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .principal) {
                Text("Details")
                    .font(.headline)
            }
        }
        .onAppear {
            loadSampleData()
        }
        .safeAreaInset(edge: .bottom) {
            Button(action: {
                showStatusUpdateSheet = true
            }) {
                Text("Update Status")
                    .font(.headline)
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.blue)
                    .cornerRadius(10)
            }
            .padding()
            .background(Color(.systemGray6))
        }
    }
    
    private func loadSampleData() {
        serviceRequirements = [
            ServiceRequirement(icon: "oil", title: "Oil Change", status: .completed),
            ServiceRequirement(icon: "wrench", title: "Brake Inspection", status: .inProgress),
            ServiceRequirement(icon: "rotate", title: "Tire Rotation", status: .pending),
            ServiceRequirement(icon: "filter", title: "Filter Replacement", status: .pending)
        ]
        
        usedParts = [
            UsedPart(quantity: 1, name: "Engine Oil Filter", partNumber: "EF-123", price: 45.99),
            UsedPart(quantity: 4, name: "Brake Pads", partNumber: "BP-456", price: 189.99),
            UsedPart(quantity: 1, name: "Air Filter", partNumber: "AF-789", price: 29.99)
        ]
    }
}

struct VehicleHeaderView: View {
    let vehicle: Vehicle
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            // Vehicle Image and Basic Info
            HStack(spacing: 16) {
                AsyncImage(url: URL(string: vehicle.vehicleImage)) { image in
                    image.resizable()
                } placeholder: {
                    Color.gray.opacity(0.3)
                }
                .frame(width: 80, height: 80)
                .cornerRadius(10)
                
                VStack(alignment: .leading, spacing: 4) {
                    Text(vehicle.registrationNumber)
                        .font(.title2)
                        .fontWeight(.bold)
                    
                    Text("\(vehicle.model) • 2023")
                        .foregroundColor(.secondary)
                    
                    Text("VIN: 1FUJGLD16MLFY7652")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }
            .padding()
        }
    }
}

struct StatusCardsView: View {
    var body: some View {
        HStack(spacing: 12) {
            // Current Status Card
            VStack(alignment: .leading, spacing: 8) {
                HStack {
                    Image(systemName: "checkmark.circle.fill")
                        .foregroundColor(.green)
                    Text("Current Status")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                }
                Text("In Service")
                    .foregroundColor(.green)
                    .fontWeight(.medium)
            }
            .padding()
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Color.white)
            .cornerRadius(10)
            
            // Next Service Card
            VStack(alignment: .leading, spacing: 8) {
                HStack {
                    Image(systemName: "exclamationmark.triangle.fill")
                        .foregroundColor(.red)
                    Text("Next Service")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                }
                Text("Due in 2 days")
                    .foregroundColor(.red)
                    .fontWeight(.medium)
            }
            .padding()
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Color.white)
            .cornerRadius(10)
        }
        .padding(.horizontal)
    }
}

struct ServiceRequirementRow: View {
    let requirement: ServiceRequirement
    
    var body: some View {
        HStack {
            Image(systemName: requirement.icon)
                .frame(width: 24, height: 24)
                .foregroundColor(.gray)
            
            Text(requirement.title)
                .font(.body)
            
            Spacer()
            
            Text(requirement.status.rawValue)
                .font(.subheadline)
                .foregroundColor(requirement.status.color)
            
            Image(systemName: "chevron.right")
                .foregroundColor(.gray)
        }
        .padding()
    }
}

struct UsedPartRow: View {
    let part: UsedPart
    
    var body: some View {
        HStack(alignment: .top) {
            Text("\(part.quantity)x")
                .font(.subheadline)
                .foregroundColor(.secondary)
                .frame(width: 30)
            
            VStack(alignment: .leading, spacing: 4) {
                Text(part.name)
                    .font(.body)
                Text("Part No: \(part.partNumber)")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            
            Spacer()
            
            Text("$\(String(format: "%.2f", part.price))")
                .font(.body)
        }
    }
}

struct VehicleMaintenanceDetailView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            VehicleMaintenanceDetailView(vehicle: Vehicle(
                type: .truck,
                model: "Volvo FH16",
                registrationNumber: "Truck#1234",
                fuelType: .diesel,
                mileage: 45678,
                rc: "RC12345",
                vehicleImage: "https://example.com/truck.jpg",
                insurance: "INS789",
                pollution: "PUC456",
                status: true
            ))
        }
    }
}
