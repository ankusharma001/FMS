//
//  SOS_Screen.swift
//  FMS
//
//  Created by Vansh Sharma on 20/02/25.
//
//

import SwiftUI

struct SOSAlert: Identifiable {
    let id = UUID()
    let driver: Driver
    let timestamp: Date
    let location: String
    var timeAgo: String {
        // Simple time ago calculation
        let minutes = Int(-timestamp.timeIntervalSinceNow / 60)
        return "\(minutes)m ago"
    }
    var formattedTime: String {
        let formatter = DateFormatter()
        formatter.dateFormat = "h:mm a"
        return formatter.string(from: timestamp)
    }
}

struct SOSView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var activeAlerts: [SOSAlert] = []
    
    var body: some View {
        NavigationView {
            VStack(spacing: 0) {
                // List of SOS alerts
                ScrollView {
                    LazyVStack(spacing: 16) {
                        ForEach(activeAlerts) { alert in
                            SOSAlertCard(alert: alert)
                        }
                    }
                    .padding()
                }
                .background(Color(.systemGray6))
            }
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .principal) {
                    Text("SOS")
                        .font(.headline)
                }
                ToolbarItem(placement: .navigationBarLeading) {
                    Button(action: {
                        dismiss()
                    }) {
                        HStack {
                            Image(systemName: "chevron.left")
                            Text("Back")
                        }
                        .foregroundColor(.blue)
                    }
                }
            }
        }
        .onAppear {
            loadSampleAlerts()
        }
    }
    
    private func loadSampleAlerts() {
        // Create sample drivers and alerts
        let driver1 = Driver(
            name: "Michael Johnson",
            email: "michael@example.com",
            phone: "123-456-7890",
            experience: .moreThanFive,
            license: "DR45892",
            geoPreference: .plain,
            vehiclePreference: .truck,
            status: true
        )
        
        let driver2 = Driver(
            name: "Sarah Williams",
            email: "sarah@example.com",
            phone: "123-456-7891",
            experience: .lessThanFive,
            license: "DR45893",
            geoPreference: .plain,
            vehiclePreference: .van,
            status: true
        )
        
        let driver3 = Driver(
            name: "David Brown",
            email: "david@example.com",
            phone: "123-456-7892",
            experience: .lessThanOne,
            license: "DR45894",
            geoPreference: .hilly,
            vehiclePreference: .truck,
            status: true
        )
        
        // Create alerts with timestamps a few minutes ago
        activeAlerts = [
            SOSAlert(
                driver: driver1,
                timestamp: Date().addingTimeInterval(-120),
                location: "123 Emergency Street, New York, NY"
            ),
            SOSAlert(
                driver: driver2,
                timestamp: Date().addingTimeInterval(-300),
                location: "456 Safety Avenue, Brooklyn, NY"
            ),
            SOSAlert(
                driver: driver3,
                timestamp: Date().addingTimeInterval(-420),
                location: "789 Alert Road, Queens, NY"
            )
        ]
    }
}

struct SOSAlertCard: View {
    let alert: SOSAlert
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                // SOS Active indicator
                Text("SOS ACTIVE")
                    .font(.caption)
                    .fontWeight(.medium)
                    .foregroundColor(.red)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 4)
                    .background(Color.red.opacity(0.1))
                    .cornerRadius(4)
                
                Spacer()
                
                // Time information
                VStack(alignment: .trailing, spacing: 2) {
                    Text(alert.formattedTime)
                        .font(.subheadline)
                        .foregroundColor(.primary)
                    Text(alert.timeAgo)
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }
            
            // Driver information
            Text(alert.driver.name)
                .font(.title3)
                .fontWeight(.semibold)
            
            Text(alert.driver.license)
                .font(.subheadline)
                .foregroundColor(.secondary)
            
            // Location
            HStack(spacing: 8) {
                Image(systemName: "location.fill")
                    .foregroundColor(.red)
                Text(alert.location)
                    .font(.subheadline)
                    .foregroundColor(.secondary)
            }
        }
        .padding()
        .background(Color.white)
        .cornerRadius(12)
        .shadow(color: Color.black.opacity(0.05), radius: 5, x: 0, y: 2)
    }
}

struct SOSView_Previews: PreviewProvider {
    static var previews: some View {
        SOSView()
    }
}
